package web.group05.trentoticketing.Data.Enums;

public enum Event_Location {
    TRENTO,
    POVO,
    ROVERETO,
    RIVA_DEL_GARDA,
    ARCO
}
