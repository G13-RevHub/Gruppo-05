package web.group05.trentoticketing.Data.Enums;

public enum Event_Type {
    CONCERTO,
    SPETTACOLO_TEATRALE,
    EVENTO_SPORTIVO,
    VISITA_GUIDATA,
    MOSTRE,
    MUSEO
}
